<script setup>

</script>

<template>
  <section class="main-box sectionList">


    <div class="col1 col">
      <div class="format">
        <h3>
          <img src="../../../public/images/image/theme.png" style="height: 20px; margin-bottom: -2px">
          &nbsp;联合会议主题
        </h3>

        <div  class="article article1"> <h5>粗糙集与软计算</h5>
          <p>粗糙集理论及应用</p>
          <p>模糊集理论及应用</p>
          <p>近似推理与不确定性分析</p>
          <p>多准则决策分析</p>
          <p>进化计算</p>
          <p>神经计算</p>
          <p>类脑计算</p>
          <p>认知计算</p>
          <p>云模型理论及其应用</p>

        </div>

        <div   class="article article2"> <h5>粒计算理论及其应用</h5>
          <p>商空间理论及应用</p>
          <p>粒逻辑与推理</p>
          <p>形式概念分析</p>
          <p>信息粒的表示</p>
          <p>信息粒化</p>
          <p>粒度选择</p>
          <p>粒计算的模式分析与处理</p>
          <p>多粒度推理模型</p>
          <p>多粒度认知计算</p>
          <p>多粒度智能决策</p>
          <p>多粒度时空数据挖掘</p>
          <!--<p>粒分类器</p>-->
        </div>
        <div  class="article article3"> <h5>三支决策模型与分析</h5>
          <p>三支决策与粗糙集</p>
          <p>三支决策与区间集</p>
          <p>三支决策与粒计算</p>
          <p>三支决策与模糊集</p>
          <p>三支决策与概念格</p>
          <p>三支决策的数学模型</p>
          <p>三支决策空间</p>
          <p>三支聚类</p>
          <p>动态三支决策</p>
          <p>序贯三支决策</p>
          <!--<p>基于三支决策的应用</p>-->
        </div>
        <div  class="article article4"> <h5>知识发现与数据挖掘</h5>
          <p>分类学习</p>
          <p>数据聚类</p>
          <p>关联和相关性</p>
          <p>时间序列挖掘</p>
          <p>知识演化</p>
          <p>衰退分析</p>
          <p>决策树</p>
          <p>神经网络</p>
          <p>遗传算法</p>
          <p>模糊分类和聚类</p>
          <p>粗糙分类</p>
          <p>规则归纳</p>
          <p>多粒度知识发现和建模</p>
          <p>可解释机器学习</p>
        </div>
        <div  class="article article5"> <h5>人工智能创新应用</h5>
          <p>智慧医疗</p>
          <p>智能制造</p>
          <p>智慧城市</p>
          <p>智慧交通</p>
          <p>智慧海洋</p>
          <p>多尺度媒体数据分析</p>
          <p>元宇宙</p>
          <p>多粒度深度学习</p>
        </div>

      </div>
    </div>




  </section>

</template>

<style scoped>

/*大会主题语及高峰论坛主题*/
.article{margin: 30px 40px;
  /* float: left; */
  /* margin-left: 162px; */
  display: inline-block;
  vertical-align: top;}
h5{
  line-height:40px;
  font-size:16px;}
.article p{

  font-size:14px;
  line-height:30px;

}

/*
.article1{margin-left: -14px;}
*/
.article2{margin-left: -14px;}
.article3{margin-left: -14px;}
.article4{margin-left: -14px;}
.article5{margin-left: -14px;}

.format{
  /*margin-left:56px;
  margin-right:56px;*/}
.format h5{
  font-size:20px;
  line-height:44px;
  margin-top:30px;
  margin-left: 20px;}
.format p{
  font-size:14px;
  text-indent:2em;
  line-height:35px;}
.format p b{font-size:15px;}
.format p a{color:#09c;}
</style>
